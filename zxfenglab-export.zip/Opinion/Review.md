# Review

### This session includes the in-house reviews focusing on specific topics.

## Content


1. [Modeling co-evolution of amino acid residues: principles and applications](/doc/modeling-co-evolution-of-amino-acid-residues-principles-and-applications-8B4ADz6rYM)
2. \


