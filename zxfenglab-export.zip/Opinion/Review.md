# Review

### This session includes the in-house reviews focusing on specific topics. 

## Content


1. Modeling co-evolution of amino acids residuals: principles and applications
2. \


