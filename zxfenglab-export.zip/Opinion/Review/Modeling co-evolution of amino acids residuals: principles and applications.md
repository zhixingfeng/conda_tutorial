# Modeling co-evolution of amino acids residuals: principles and applications

