# Install software packages with conda

