# Tools

## Information collection


1. [MarkDownload - Markdown Web Clipper](https://chrome.google.com/webstore/detail/markdownload-markdown-web/pcmpcfapbekmbjjkdalcgopdkipoggdi/related?hl=en-GB) : This is a Chrome extension that can save webpage to Markdown file, very useful to add copy public web article to our knowledge base.

   \


