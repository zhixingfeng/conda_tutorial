# Conda 

* [Install software packages with conda ](/doc/install-software-packages-with-conda-5AvXVCgagm)
* [Create software packages with conda](/doc/create-software-packages-with-conda-cUATI4gKzG)
* [Upload software packages to bioconda ](/doc/upload-software-packages-to-bioconda-3ItEorPHa8)


