# Cheat Sheet 


1. [Conda](https://docs.conda.io/projects/conda/en/4.6.0/_downloads/52a95608c49671267e40c689e0bc00ca/conda-cheatsheet.pdf)
2. [Julia language](https://juliadocs.github.io/Julia-Cheat-Sheet/)


