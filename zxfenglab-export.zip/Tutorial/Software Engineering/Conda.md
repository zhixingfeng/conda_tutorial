# Conda

# Conda

* [Install software packages with conda](/doc/install-software-packages-with-conda-ZPGOKRqwFA)
* [Create software packages with conda](/doc/create-software-packages-with-conda-bXdHlRErZ3)
* [Upload software packages to bioconda](/doc/upload-software-packages-to-bioconda-9JYQjsLqCI)
* [Example](/doc/examples-BxyYoFjccG) 


