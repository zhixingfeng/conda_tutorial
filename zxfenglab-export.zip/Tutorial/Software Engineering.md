# Software Engineering

* [Use Conda to develop and manage software](/doc/conda-YYovRQa1NC)
* [Setup a web server](/doc/setup-a-web-server-115AZ9Fu72)
* [Useful tools](/doc/tools-ATh4TTgN9L) \n 


