# Software

* [Use Conda to develop and manage software](/doc/conda-Zva8Ih1Dq1)


* [Setup a web server ](/doc/setup-http-web-server-WxpaKFhQIx)
* [Useful tools](/doc/tools-9PavvduhbC) \n 


