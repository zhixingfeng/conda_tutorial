# Databases

## Human Genome


1. [Genome Aggregation Database](https://gnomad.broadinstitute.org): a large database contains about 125k human exomes and 15k human genomes.

## Microbiome


1. [MGnify](https://www.ebi.ac.uk/metagenomics/): a large collection of microbiome data hosted by EBI.


