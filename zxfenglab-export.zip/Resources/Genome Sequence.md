# Genome Sequence

## Human


1. [Genome Aggregation Database](https://gnomad.broadinstitute.org): a large database contains about 125k human exomes and 15k human genomes.
2. \


